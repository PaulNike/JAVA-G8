package com.codigo.ms_registro_hexagonal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsRegistroHexagonalApplicationTests {

	@Test
	void contextLoads() {
	}

}
