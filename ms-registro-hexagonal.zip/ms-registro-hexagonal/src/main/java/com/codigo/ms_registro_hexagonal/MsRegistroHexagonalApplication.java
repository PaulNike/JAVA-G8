package com.codigo.ms_registro_hexagonal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsRegistroHexagonalApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsRegistroHexagonalApplication.class, args);
	}

}
