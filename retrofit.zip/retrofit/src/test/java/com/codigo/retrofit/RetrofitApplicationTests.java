package com.codigo.retrofit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetrofitApplicationTests {

	@Test
	void contextLoads() {
	}

}
